package datanucleus;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManagerFactory;

import org.junit.Assert;
import org.junit.Test;

import com.example.datanucleus.dao.DAO;
import com.example.datanucleus.dao.Flight;
import com.example.datanucleus.dao.FlightDao;
import com.example.datanucleus.dao.dn.FlightDaoImplement;

public class FlightDaoImplTest {
	
	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("Example");
	FlightDao flightDao = new FlightDaoImplement(pmf);
	
	//Flight f1 = new Flight("versailles", "boulogne", "2021-05-19 10:00", "2021-05-19 10:45", 4, 30, "ok", 2);
	/*Flight f2 = new Flight();
	Flight f3 = new Flight();
	Flight f4 = new Flight();
	
	public void initiate() {
		f1.setDepartureAerodrome("Vincennes");
		f1.setAvailablePlaces(0);
		f2.setDepartureAerodrome("Versailles");
		f2.setAvailablePlaces(3);
		f3.setDepartureAerodrome("Boulogne");
		f3.setAvailablePlaces(2);
		f4.setDepartureAerodrome("Fontainebleau");
		f4.setAvailablePlaces(0);
	}
	public void addFourFlights() {
		flightDao.addFlight(f1);
		//flightDao.addFlight(f2);
		//flightDao.addFlight(f3);
		//flightDao.addFlight(f4);
	}*/
	
	//@Test
	/**
	 * checking for addFlights and getFlights
	 
	public void addGet() {
		Assert.assertEquals(0, flightDao.getFlights().size());
		initiate();
		addFourFlights();
		Assert.assertEquals(4, flightDao.getFlights().size());
		DAO.getFlightDao().getFlights().stream().forEach(s->System.out.println("addGet JunitTest: " + s.getDepartureAerodrome()));	
	}*/
	
	@Test
	/**
	 * checking for add and search flights
	 */
	public void addGetFlight() {
		Assert.assertEquals(0, flightDao.getFlights().size());
		flightDao.addFlight("versailles", "boulogne", "2021-05-19 10:00", "2021-05-19 10:45", 4, 30, "ok", 2);
		flightDao.addFlight("montagne", "boulogne", "2020-05-19 10:00", "2020-05-19 10:45", 4, 30, "ok", 2);
		Assert.assertEquals(2, flightDao.getFlights().size());
		Assert.assertEquals(1, flightDao.getFlights("versailles", "2021-04-19 10:00", "2021-07-19 10:00").size());
		DAO.getFlightDao().getFlights().stream().forEach(s->System.out.println("addGet JunitTest: " + s.getDepartureAerodrome()));
		DAO.getFlightDao().getFlights("versailles", "2021-04-19 10:00", "2021-07-19 10:00").stream().forEach(s->System.out.println("addGet JunitTest: " + s.getDepartureAerodrome()));
	}
}
