package com.example.datanucleus.dao;

import java.util.List;

public interface PilotDao {

	/**
	 * @return a list of all pilots registered
	 */
	List<Pilot> getPilots();

	/**
	 * @param id
	 * @return a pilot
	 */
	Pilot getPilot(long id);
	
	/**
	 * @param id
	 * @return pilot's id
	 */
	int isPilot(long id);

	/**
	 * add a new signed up pilot
	 * 
	 * @param p
	 * @return boolean if p has been added
	 */
	boolean addPilot(String firstName, String lastName, String birthday, int phone, String email, String password, String experience, String qualifications, int numFlightHours, String airplaneBrand);
}
