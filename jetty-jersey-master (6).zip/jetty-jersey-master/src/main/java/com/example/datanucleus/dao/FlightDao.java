package com.example.datanucleus.dao;

import java.time.LocalDateTime;
import java.util.List;

public interface FlightDao {
	/**
	 * @return list of all flights
	 */
	List<Flight> getFlights();

	/**
	 * @return list of specific available flights
	 */
	List<Flight> getFlights(String departure, String from, String to);

	/**
	 * @param id
	 * @return flight
	 */
	Flight getFlight(long id);

	/**
	 * add a flight
	 * 
	 * @param f
	 * @return boolean if f has been added
	 */
	boolean addFlight(String departureAerodrome, String arrivalAerodrome, String departureTimeString, String arrivalTimeString, int availablePlaces, int price, String meetingPlace, long idOwner);

	/**
	 * modify flight's field
	 * 
	 * @param f
	 * @return true if succeed
	 */
	boolean bookFlight(long flightId, int nbPlacesBooked, long userId);

	/**
	 * remove a flight
	 * 
	 * @param f
	 * @return true if succeed
	 */
	boolean delFlight(long flightId, long pilotId);
}
