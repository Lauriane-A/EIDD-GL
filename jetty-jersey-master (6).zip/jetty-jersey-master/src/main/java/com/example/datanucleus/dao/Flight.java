package com.example.datanucleus.dao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable
public class Flight {
	@PrimaryKey
	@Persistent(valueStrategy = IdGeneratorStrategy.INCREMENT)
	private long flightId;
	private String departureAerodrome;
	private String arrivalAerodrome;
	//private LocalDateTime departureTime;
	//private LocalDateTime arrivalTime;
	private String departureTimeString;
	private String arrivalTimeString;
	private int availablePlaces;
	private int price;
	private String meetingPlace;
	private long ownerId;
	@Persistent
	private List<Long> subscribedId = new ArrayList<Long>();
	
	public Flight (String departureAerodrome, String arrivalAerodrome, String departureTimeString, String arrivalTimeString, int availablePlaces, int price, String meetingPlace, long idOwner) {
		this.departureAerodrome = departureAerodrome;
		this.arrivalAerodrome = arrivalAerodrome;
		//this.departureTime = departureTime;
		//this.arrivalTime = arrivalTime;
		this.departureTimeString = departureTimeString;
		this.arrivalTimeString = arrivalTimeString;
		this.availablePlaces = availablePlaces;
		this.price = price;
		this.meetingPlace = meetingPlace;
		this.ownerId = idOwner;
	}
	public long getId() {
		return flightId;
	}

	public void setId(int id) {
		this.flightId = id;
	}

	public String getDepartureAerodrome() {
		return departureAerodrome;
	}

	public void setDepartureAerodrome(String departureAerodrome) {
		this.departureAerodrome = departureAerodrome;
	}

	public String getArrivalAerodrome() {
		return arrivalAerodrome;
	}

	public void setArrivalAerodrome(String arrivalAerodrome) {
		this.arrivalAerodrome = arrivalAerodrome;
	}

	public int getAvailablePlaces() {
		return availablePlaces;
	}

	public void setAvailablePlaces(int availablePlaces) {
		this.availablePlaces = availablePlaces;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getMeetingPlace() {
		return meetingPlace;
	}

	public void setMeetingPlace(String meetingPlace) {
		this.meetingPlace = meetingPlace;
	}

	public List<Long> getSubscribed() {
		return subscribedId;
	}

	public void setSubscribed(List<Long> subscribed) {
		this.subscribedId = subscribed;
	}

	public long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(long ownerId) {
		this.ownerId = ownerId;
	}

	public String getDepartureTimeString() {
		return departureTimeString;
	}

	public void setDepartureTimeString(String departureTimeString) {
		this.departureTimeString = departureTimeString;
	}

	public String getArrivalTimeString() {
		return arrivalTimeString;
	}

	public void setArrivalTimeString(String arrivalTimeString) {
		this.arrivalTimeString = arrivalTimeString;
	}
}
