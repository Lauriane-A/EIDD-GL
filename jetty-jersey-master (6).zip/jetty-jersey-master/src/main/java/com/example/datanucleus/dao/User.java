package com.example.datanucleus.dao;
import java.time.LocalDate;
import java.util.List;

import javax.jdo.annotations.IdGeneratorStrategy;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.jdo.annotations.PrimaryKey;

@PersistenceCapable
public class User {
	@PrimaryKey
	@Persistent(valueStrategy = IdGeneratorStrategy.INCREMENT)
	private long id;
	private String firstName;
	private String lastName;
	private String birthday;
	private int phone;
	private String email;
	private String password;
	@Persistent
	private List<Long> bookedFlights;

	public User(String firstN, String lastN, String birthday, int phone, String email, String password) {
		this.firstName = firstN;
		this.lastName = lastN;
		this.birthday = birthday;
		this.phone = phone;
		this.email = email;
		this.password = password;
		this.bookedFlights = null;
	}
	
	public User() {}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Long> getBookedFlights() {
		return bookedFlights;
	}

	public void setBookedFlights(List<Long> bookedFlights) {
		this.bookedFlights = bookedFlights;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
