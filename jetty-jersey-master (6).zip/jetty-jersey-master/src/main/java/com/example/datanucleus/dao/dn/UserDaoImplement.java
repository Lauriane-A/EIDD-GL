package com.example.datanucleus.dao.dn;


import java.util.ArrayList;
import java.util.List;

import javax.jdo.JDOObjectNotFoundException;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

import com.example.datanucleus.dao.Pilot;
import com.example.datanucleus.dao.User;
import com.example.datanucleus.dao.UserDao;

public class UserDaoImplement implements UserDao {

	private PersistenceManagerFactory pmf;

	public UserDaoImplement(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
	}

	@SuppressWarnings("unchecked")
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		List<User> listUsers = null;
		List<User> detached = new ArrayList<User>();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Query q = pm.newQuery(User.class); // id ?
			listUsers = (List<User>) q.execute();
			detached = (List<User>) pm.detachCopyAll(listUsers);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}

	public User getUser(long id) {
		// TODO Auto-generated method stub
		User detached = null;
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		User u = null;
		try {
			tx.begin();
			u = pm.getObjectById(User.class, id);
			detached = (User) pm.detachCopy(u);
			tx.commit();
		} catch (JDOObjectNotFoundException e) {
			return null;
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}

	public boolean addUser(String firstN, String lastN, String birthday, int phone, String email, String password) {
		// TODO Auto-generated method stub
		List<User> allUsers = getUsers();
		for (User u: allUsers) {
			if(u.getEmail().equals(email)) {
				return false;
			}
		}
		User user = new User (firstN, lastN, birthday, phone, email, password);
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		//String emailAddress = user.getEmail();
		try {
			tx.begin();
			pm.makePersistent(user);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return true;
	}

	public long login(String email, String pwd) {
		// TODO Auto-generated method stub
		List<User> allUsers = getUsers();
		for (User u : allUsers) {
			if (u.getEmail().equals(email) && u.getPassword().equals(pwd)) {
				return u.getId();
			}
		}
		return 0;
	}
}
