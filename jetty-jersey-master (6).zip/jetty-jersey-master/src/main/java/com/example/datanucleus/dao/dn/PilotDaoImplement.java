package com.example.datanucleus.dao.dn;

import java.util.ArrayList;
import java.util.List;

import javax.jdo.JDOObjectNotFoundException;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

import com.example.datanucleus.dao.Pilot;
import com.example.datanucleus.dao.PilotDao;

public class PilotDaoImplement implements PilotDao {
	
	private PersistenceManagerFactory pmf;

	public PilotDaoImplement(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
	}

	@SuppressWarnings("unchecked")
	public List<Pilot> getPilots() {
		// TODO Auto-generated method stub
		List<Pilot> listPilots = null;
		List<Pilot> detached = new ArrayList<Pilot>();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Query q = pm.newQuery(Pilot.class);
			listPilots = (List<Pilot>) q.execute();
			detached = (List<Pilot>) pm.detachCopyAll(listPilots);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}

	public Pilot getPilot(long id) {
		// TODO Auto-generated method stub
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		Pilot detached = null;
		Pilot p = null;
		try {
			tx.begin();
			p = pm.getObjectById(Pilot.class, id);
			detached = (Pilot) pm.detachCopy(p);
			tx.commit();
		} catch (JDOObjectNotFoundException e) {
			return null;
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}

	public boolean addPilot(String firstName, String lastName, String birthday, int phone, String email,
			String password, String experience, String qualifications, int numFlightHours, String airplaneBrand) {
		// TODO Auto-generated method stub
		Pilot p = new Pilot (firstName, lastName, birthday, phone, email, password, experience, qualifications, numFlightHours, airplaneBrand);
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			pm.makePersistent(p);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return true;
	}

	public int isPilot(long id) {
		// TODO Auto-generated method stub
		if (getPilot(id) == null) {
			return 0; //not a pilot
		} else {
			return 1; //pilot
		}
	}

}
