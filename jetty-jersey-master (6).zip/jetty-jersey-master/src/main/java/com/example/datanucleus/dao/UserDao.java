package com.example.datanucleus.dao;

import java.util.List;

public interface UserDao {

	/*
	 * @return a list of all registered passengers
	 */
	List<User> getUsers();

	/**
	 * find a passenger by id number
	 * 
	 * @param id
	 * @return passenger who matches with id
	 */
	User getUser(long id);

	/**
	 * add a new signed up passenger
	 * 
	 * @param u
	 * @return boolean if p has been added
	 */
	boolean addUser(String firstN, String lastN, String birthday, int phone, String email, String password);
	
	/**
	 * 
	 * @param email
	 * @param pwd
	 * @return id of user, 0 if user not found
	 */
	long login (String email, String pwd);
}
