package com.example.datanucleus.dao;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManagerFactory;

import com.example.datanucleus.dao.dn.FlightDaoImplement;
import com.example.datanucleus.dao.dn.PilotDaoImplement;
import com.example.datanucleus.dao.dn.UserDaoImplement;
import com.example.datanucleus.dao.fake.ActionDaoFakeImpl;

public class DAO {
	
	static PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("Example");

	public static ActionDao getActionDao() {
		return new ActionDaoFakeImpl();
	}

	public static FlightDao getFlightDao() {
		return new FlightDaoImplement(pmf);
	}

	public static UserDao getUserDao() {
		return new UserDaoImplement(pmf);
	}
	
	public static PilotDao getPilotDao() {
		return new PilotDaoImplement(pmf);
	}
}
