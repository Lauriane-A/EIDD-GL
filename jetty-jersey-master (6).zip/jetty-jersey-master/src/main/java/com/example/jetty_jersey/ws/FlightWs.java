package com.example.jetty_jersey.ws;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.example.datanucleus.dao.DAO;
import com.example.datanucleus.dao.Flight;

@Path("/flights")
public class FlightWs {

	public static class BookedClass {
		public int idFlight;
		public int nbPlacesBooked;
		public int idUser;
		
		public BookedClass() {}
		
		public BookedClass(int idFlight, int nbPlacesBooked, int idUser) {
			this.idFlight = idFlight;
			this.nbPlacesBooked = nbPlacesBooked;
			this.idUser = idUser;
		}
		
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/available-flights/{departure}/{from}/{to}")
	public List<Flight> getFlightlist(@PathParam("departure") String departure, @PathParam("from") String from, @PathParam("to") String  to) {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().getFlights(departure, from, to);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Flight getFlight(@PathParam("id") long id) {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().getFlight(id);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public List<Flight> getFlights() {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().getFlights();
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/add")
	public boolean addFlight(Flight f) {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().addFlight(f.getDepartureAerodrome(), f.getArrivalAerodrome(), f.getDepartureTimeString(), f.getDepartureTimeString(), f.getAvailablePlaces(), f.getPrice(), f.getMeetingPlace(), f.getOwnerId());
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/book")
	public boolean updateFlight(BookedClass b) {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().bookFlight(b.idFlight, b.nbPlacesBooked, b.idUser);
	}

	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/delete/{id}")
	public boolean delFlight(@PathParam("id") long id) {
		// TODO Auto-generated method stub
		return DAO.getFlightDao().delFlight(id,id);
	}
}
