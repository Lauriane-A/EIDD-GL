function fillTable(containerlist) {
    var templatelist = _.template($('#templateRow').html());
    var resultlist = "";
    containerlist.forEach(action => resultlist += templatelist(action));
	//var htmlresult=template({"attribut":JSON.stringify(result)}); 
    //$("#result").append(htmlresult);
	$("#result1").html(resultlist);
}


$(function () {
    $("#listflight").click(function () {
        // var id11 = $("#departureaerodrome").val();
		getServerData("ws/flights/list", fillTable);
    });
});