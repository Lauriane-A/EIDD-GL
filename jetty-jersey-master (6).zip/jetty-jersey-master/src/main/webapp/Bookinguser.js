const queryString=window.location.search;
console.log(queryString);
const urlParems=new URLSearchParams(queryString);
const id=urlParems.get('id');

function fonction(){
	// Charger les valeurs saisies par l'utilisateur
	<script type="text/javascript" src="firstpage.js"></script>
	var bookedClass = {
		"idFlight":Number.parseInt(id,10),
		"nbPlacesBooked":Number.parseInt($("#place").val(),10),
		"idUser":iduser,		
	
	};
	postServerData("ws/flights/book",bookedClass,  function(bool){
		if(bool==false)alert("booking failed");
		else alert("your flight has been successfully booked");
	});
	
	
}