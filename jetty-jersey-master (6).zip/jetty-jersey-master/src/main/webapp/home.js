
function callDone(result){
	var templateExample = _.template($('#templateExample').html());

	var html = templateExample({
		"attribute":JSON.stringify(result)
	});

	$("#result").append(html);
}

/*$(function(){
	$("#button").click(function(){
		getServerData("ws/flights/list",callDone);
	});
});*/

$(function(){
	$("#button").click(function(){
		putServerData("ws/users/sign-up",callDone);
	});
});

/*$(function(){
	$("#button").click(function(){
		var paramsWebservice={
			"price":$("#100").val(),
		};
		postServerData("FlightWs/flights/add",paramsWebservice , callDone);
	});
});*/