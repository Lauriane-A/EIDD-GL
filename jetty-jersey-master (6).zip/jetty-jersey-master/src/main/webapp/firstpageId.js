const queryString=window.location.search;
console.log(queryString);
const urlParems=new URLSearchParams(queryString);
const id=urlParems.get('id');
var iduser=Number.parseInt(id,10);
	
function fillTable(container) {
    var template = _.template($('#templateRow').html());
    var result = "";
	//container.forEach(action => result += template(action));
	//var htmlresult=template({"attribut":JSON.stringify(result)}); 
    //$("#result").append(htmlresult);
	$("#result").html(result);
}


$(function () {
    $("#buttonSearch").click(function () {
        var id1 = $("#departureaerodrome").val();
		var id2 = $("#departureDate").val();
		var id3 = $("#arrivalDate").val();
		//getServerData("ws/flights/available-flights/" + id1, fillTable);
        getServerData("ws/flights/available-flights/" + id1+ "/"+id2+ "/"+id3, fillTable);
	});
	getServerData("ws/flights/available-flights/" + id1+ "/"+id2+ "/"+id3, function(list){
			if(list==[])alert("no flight to show");
	});
});
//}

