function success(){
	var templateExample = _.template($('#templatesignupsucess').html());
	var html = templateExample({});

	$("#sucess").html(html);
}

$(function () {
    $("#passengerAdd").click(function () {
		var user = {
		"firstName":$("#name").val(),
		"lastName":$("#lastname").val(),
		"birthday":$("#dateofbirth").val(),
		"phone":Number.parseInt($("#phone").val(),10),
		"email":$("#mail").val(),
		"password":$("#password").val(),
	};
		putServerData("ws/users/sign-up",user,  function(bool){
			if(bool==false)alert("mail already existe");
			else { 
				getServerData("ws/users/sign-in/"+ user.email+ "/"+user.password,function(bool){
				if(bool==0)alert("username or password incorrect");
				else  { 
					setTimeout(function(){
                	window.location.href = "firstpageUser.html?id="+ bool;
					}, 1000);
					};
				});
			};
		});
    });
});

function pilotadd(){
	// Charger les valeurs saisies par l'utilisateur
	var pilot = {
		"firstName":$("#name").val(),
		"lastName":$("#lastname").val(),
		"birthday":$("#dateofbirth").val(),
		"phone":Number.parseInt($("#phone").val(),10),
		"email":$("#mail").val(),
		"password":$("#password").val(),
		"experience":$("#experience").val(),
		"qualifications":$("#qualifications").val(),
		"numFlightHours":Number.parseInt($("#numFlightHours").val(),10),
		"airplaneBrand":$("#airplaneBrand").val(),
	};
	putServerData("ws/pilots/sign-up",pilot,  function(bool){
			if(bool==false)alert("mail already existe");
			else { getServerData("ws/users/sign-in/"+ pilot.email+ "/"+pilot.password,function(bool){
				if(bool==0)alert("username or password incorrect");
				else  { 
					setTimeout(function(){
                	window.location.href = "firstpagePilot.html?id="+ bool;
					}, 1000);
				};
			});
		};
	});
		
}