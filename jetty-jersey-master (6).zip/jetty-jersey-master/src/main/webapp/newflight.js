const queryString=window.location.search;
console.log(queryString);
const urlParems=new URLSearchParams(queryString);
const id=urlParems.get('id');

function fonction(){
	// Charger les valeurs saisies par l'utilisateur

	var flight = {
		departureAerodrome:$("#departure").val(),
		arrivalAerodrome:$("#arrival").val(),
		meetingPlace:$("#meetingplace").val(),
		price:Number.parseInt($("#price").val(),10),
		//departureTime:$("#departuredate").val(),
		departureTimeString:$("#departuredate").val(),
		//arrivalTime:$("#arrivaldate").val(),
		departureTimeString:$("#arrivaldate").val(),
		availablePlaces:Number.parseInt($("#seatnb").val(),10),
		ownerId: id, 
	};
	
	
	
	putServerData("ws/flights/add",flight,  function(bool){
		if(bool==false)alert("error during planning a fight")
		else alert("your flight has been successfully planned");
	});
}