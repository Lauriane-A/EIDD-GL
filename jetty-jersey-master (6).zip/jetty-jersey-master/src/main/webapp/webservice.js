function getServerData(url, success){
    $.ajax({
        dataType: "json",
		type:"GET",
        url: url
    }).done(success);
}

function postServerData(url, data, success){
    $.ajax({
        url: url,
		type:"POST",
		data: JSON.stringify(data),
		contentType: "application/json",
        dataType: "json"
    }).done(success);
}

function putServerData(url, data, success){
    $.ajax({
        url: url,
		type:"PUT",
		data: JSON.stringify(data),
		contentType: "application/json",
		dataType: "json",
    }).done(success);
}

function deleteServerData(url, success){
    $.ajax({
        url: url,
		type:"DELETE",
		data: data,
		dataType: "json"
    }).done(success);
}