
function fonction(){
	// Charger les valeurs saisies par l'utilisateur
	var user = {
		"firstName":$("#name").val(),
		"lastName":$("#lastname").val(),
		"birthday":$("#dateofbirth").val(),
		"phone":Number.parseInt($("#phone").val(),10),
		"email":$("#mail").val(),
		"password":$("#password").val(),
		/*"experience":$("#experience").val(),
		"qualifications":$("#qualifications").val(),
		"numFlightHours":Number.parseInt($("#numFlightHours").val(),10),
		"airplaneBrand":$("#airplaneBrand").val(),*/
	};
	
	putServerData("ws/users/sign-up",user,  function(){
		console.log("Ok");
	});
	
	
}