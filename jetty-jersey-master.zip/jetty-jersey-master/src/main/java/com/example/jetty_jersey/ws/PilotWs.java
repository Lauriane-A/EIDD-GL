package com.example.jetty_jersey.ws;


import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.example.datanucleus.dao.DAO;
import com.example.datanucleus.dao.Pilot;
import com.example.datanucleus.dao.User;

@Path("/pilots")
public class PilotWs {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public List<Pilot> getPilots() {
		// TODO Auto-generated method stub
		return DAO.getPilotDao().getPilots();
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/sign-in/{email}/{password}")
	public long signIn(@PathParam("email") String email,@PathParam("password") String password) {
		// TODO Auto-generated method stub;
		return DAO.getUserDao().login(email, password);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Pilot getPilot(@PathParam("id") long id) {
		// TODO Auto-generated method stub
		return DAO.getPilotDao().getPilot(id);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/is/{id}")
	public int isPilot(@PathParam("id") long id) {
		// TODO Auto-generated method stub
		return DAO.getPilotDao().isPilot(id);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/sign-up")
	public boolean addPilot(Pilot u) {
		// TODO Auto-generated method stub
		//saved as user first
		DAO.getUserDao().addUser(u.getFirstName(), u.getLastName(), u.getBirthday(), u.getPhone(), u.getEmail(), u.getPassword());
		return DAO.getPilotDao().addPilot(u.getFirstName(), u.getLastName(), u.getBirthday(), u.getPhone(), u.getEmail(), u.getPassword(), u.getExperience(), u.getQualifications(), u.getNumFlightHours(), u.getAirplaneBrand());
	}
}
