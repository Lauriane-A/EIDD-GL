package com.example.jetty_jersey.ws;


import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.example.datanucleus.dao.DAO;
import com.example.datanucleus.dao.User;

@Path("/users")
public class UserWs {
	/*
	public static class UserBody{
		private String firstName;
		private String lastName;
		private String birthday;
		private int phone;
		private String email;
		private String password;
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getBirthday() {
			return birthday;
		}
		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getPhone() {
			return phone;
		}
		public void setPhone(int phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
    }*/

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/list")
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return DAO.getUserDao().getUsers();
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/sign-in/{email}/{password}")
	public long signIn(@PathParam("email") String email,@PathParam("password") String password) {
		// TODO Auto-generated method stub;
		return DAO.getUserDao().login(email, password);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public User getUser(@PathParam("id") long id) {
		// TODO Auto-generated method stub
		return DAO.getUserDao().getUser(id);
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/sign-up")
	public boolean addUser(User u) {
		// TODO Auto-generated method stub
		return DAO.getUserDao().addUser(u.getFirstName(), u.getLastName(), u.getBirthday(), u.getPhone(), u.getEmail(), u.getPassword());
	}

}
