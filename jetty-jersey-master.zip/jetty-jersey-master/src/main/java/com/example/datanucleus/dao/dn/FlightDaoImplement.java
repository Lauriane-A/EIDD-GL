package com.example.datanucleus.dao.dn;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import javax.jdo.JDOObjectNotFoundException;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

import com.example.datanucleus.dao.Flight;
import com.example.datanucleus.dao.FlightDao;

public class FlightDaoImplement implements FlightDao {

	private PersistenceManagerFactory pmf;

	public FlightDaoImplement(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
	}

	@SuppressWarnings("unchecked")
	/**
	 * return the list of all flights saved inthe data base
	 */
	public List<Flight> getFlights() {
		// TODO Auto-generated method stub
		List<Flight> listFlights = null;
		List<Flight> detached = new ArrayList<Flight>();
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Query q = pm.newQuery(Flight.class);
			listFlights = (List<Flight>) q.execute();
			detached = (List<Flight>) pm.detachCopyAll(listFlights);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}
	
	/**
	 * return the corresponding flight
	 */
	public Flight getFlight(long id) {
		// TODO Auto-generated method stub
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		Flight detached = null;
		Flight f = null;
		try {
			tx.begin();
			f = pm.getObjectById(Flight.class, id); //retrieving the flight by iD
			detached = (Flight) pm.detachCopy(f);
			tx.commit();
		} catch (JDOObjectNotFoundException e) {
			return null;
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return detached;
	}
	
	/**
	 * create a flight and add it to the data base
	 */
	public boolean addFlight(String departureAerodrome, String arrivalAerodrome, String departureTimeString, String arrivalTimeString, int availablePlaces, int price, String meetingPlace, long idOwner) {
		// TODO Auto-generated method stub
		Flight f = new Flight (departureAerodrome, arrivalAerodrome, departureTimeString, arrivalTimeString, availablePlaces, price, meetingPlace, idOwner);
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			pm.makePersistent(f);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return true;
	}

	/**
	 * decrement number of seats, add passenger to the list of the flight
	 * 
	 * @param flightId
	 * @param nbPlacesBooked
	 * @param passengerId
	 * @return
	 */
	public boolean bookFlight(long flightId, int nbPlacesBooked, long passengerId) {
		// TODO Auto-generated method stub
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		Flight flight = null;
		boolean r = false;
		try {
			tx.begin();
			flight = pm.getObjectById(Flight.class, flightId);
			int n = (flight.getAvailablePlaces() - nbPlacesBooked);
			if (n >= 0) {
				flight.setAvailablePlaces(n);
				flight.setOwnerId(passengerId);
				r = true;
			} else {
				r = false;
			}
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return r;
	}

	/**
	 * delete flight from the database
	 */
	public boolean delFlight(long flightId, long pilotId) {
		// TODO Auto-generated method stub
		Flight f = getFlight(flightId);
		// to do
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			pm.deletePersistent(f);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			pm.close();
		}
		return false;
	}

	/*
	 * @param fromString: date in String type "YYYY-MM-dd HH:MM"
	 * @param toString: date in String type "YYYY-MM-dd HH:MM"
	 * return flights with available seats corresponding to the given arguments
	 */
	public List<Flight> getFlights(String departure, String fromString, String toString) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		LocalDateTime from = LocalDateTime.parse(fromString, formatter);
		LocalDateTime end = LocalDateTime.parse(toString, formatter);
		List<Flight> allFlights = getFlights();
		if(allFlights.isEmpty()) {
			return null;
		}
		List<Flight> selectedFlights = new ArrayList<Flight>();
		//Stream<Flight> flightStream = allFlights.stream().filter(x-> x.getAvailablePlaces() > 0);
		for (Flight f : allFlights) {
			if (f.getAvailablePlaces()>0) {
				if (f.getDepartureAerodrome().equalsIgnoreCase(departure)) {
					//checking the range
					LocalDateTime fDepartureTime = LocalDateTime.parse(f.getDepartureTimeString(), formatter); 
					int compareStart = fDepartureTime.compareTo(from); //converting String to LocalDateTime type
					int compareEnd = fDepartureTime.compareTo(end);
					if (compareStart >= 0 && compareEnd <= 0) {
						selectedFlights.add(f);
					}
				}
			}
		}
		if (selectedFlights.isEmpty()) {
			return null;
		}
		return selectedFlights;
	}
}
