/*function fonction(){
	// Charger les valeurs saisies par l'utilisateur
	var user = {
		"email":$("#email").val(),
		"password":$("#password").val(),
	};
	
	getServerData("ws/users/sign-in/+ id1+ "/"+id2",user,  function(){alert('sucessfullt signed in'),failed;});
	
	
}*/

function fillTable(container) {
    var template = _.template($('#templateRow').html());
    var result = "";
    container.forEach(action => result += template(action));
	//var htmlresult=template({"attribut":JSON.stringify(result)}); 
    //$("#result").append(htmlresult);
	$("#result").html(result);
}
function isEmpty(){
             var password = $("#password").val();
             if( !str.replace(/\s+/, '').length ) {
                  alert( "Le champ Name est vide!" );
             }
}
$(function () {
    $("#buttonLoginUser").click(function () {
		var email = $("#email").val();
		var password = $("#password").val();
		if (password == "" |email == "" ){ alert("one of the field is not filled up");}
		var url;
		getServerData("ws/users/sign-in/"+ email+ "/"+password,function(bool){
			if(bool==0)alert("username or password incorrect");
			else  { 
				getServerData("ws/pilots/is/"+ bool,function(val){
				if(val==0)url="firstpageUser.html?id="+ bool;
				else url="firstpagePilot.html??id="+ bool;
			});
			setTimeout(function(){
                window.location.href = url;
				}, 1000);
			};
		});
	});
});