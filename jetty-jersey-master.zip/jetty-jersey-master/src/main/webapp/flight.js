const queryString=window.location.search;
console.log(queryString);
const urlParems=new URLSearchParams(queryString);
const id=urlParems.get('id');

function fillTable(container) {
    var template = _.template($('#templateRow').html());
    var result =  template({});
   // container.forEach(action => result += template(action));
	//var htmlresult=template({"attribut":JSON.stringify(result)}); 
    //$("#result").append(htmlresult);
    $("#result").html(result);
}


$(function () {
    $("#buttonSearch").click(function () {
        var flightId=Number.parseInt(id,10);
        getServerData("ws/flights/" + flightId, fillTable);
    });
});
