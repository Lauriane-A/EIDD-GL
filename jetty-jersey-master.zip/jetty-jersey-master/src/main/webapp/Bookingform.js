const queryString=window.location.search;
console.log(queryString);
const urlParems=new URLSearchParams(queryString);
const id=urlParems.get('id');

function fonction(){
	// Charger les valeurs saisies par l'utilisateur

	var user = {
		"firstName":$("#firstname").val(),
		"lastName":$("#Lastname").val(),
		"birthday":$("#birthday").val(),
		"phone":Number.parseInt($("#phone").val(),10),
		"email":$("#email").val(),
		"password":$("#password").val(),
	};
	putServerData("ws/users/sign-up",user,  function(bool){
			if(bool==false)alert("mail already existe");
	});
	var iduse;
	getServerData("ws/users/sign-in/"+ user.email+ "/"+user.password,function(iden){
		if(iden>0) iduse=iden;
	});
	var bookedClass = {
		"idFlight":Number.parseInt(id,10),
		"nbPlacesBooked":Number.parseInt($("#seatnb").val(),10),
		"idUser":iduse,		
	};
	postServerData("ws/flights/book",bookedClass,  function(bool){
		if(bool==false)alert("booking failed");
		else alert("your booking sucessfully done");
	});
	
	
}